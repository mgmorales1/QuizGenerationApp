import java.util.Date;

public class Ticket {
	private int timeEntered;
	private int timeLeft;
	private Date dateEntered; 
	private Date dateLeft;
	private String serialNumber;
	private String spot;
	 // for commit
	public Ticket() {
		
	}
	
	public Ticket(int time, String spot, String serialNum) {
		this.timeEntered = time;
		this.spot = spot;
		this.serialNumber = serialNum;
	}
	
	public int getTimeEntered() {
		return timeEntered;
	}
	
	public void setTimeEntered(int timeEntered) {
		this.timeEntered = timeEntered;
	}
	
	public int getTimeLeft() {
		return timeLeft;
	}
	
	public void setTimeLeft(int timeLeft) {
		this.timeLeft = timeLeft;
	}
	
	public Date getDateEntered() {
		return dateEntered;
	}
	
	public void setDateEntered(Date date) {
		this.dateEntered = date;
	}
	
	public Date getDateLeft() {
		return dateLeft;
	}

	public void setDateLeft(Date dateLeft) {
		this.dateLeft = dateLeft;
	}
	
	public String getSerialNumber() {
		return serialNumber;
	}
	
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	public String getSpot() {
		return spot;
	}
	
	public void setSpot(String spot) {
		this.spot = spot;
	}


	
}
