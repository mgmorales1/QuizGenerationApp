
public class Truck extends Vehicle{
	private int numOfSeats;
	
	public Truck() {
		
	}
	
	public Truck(int seatNum, boolean electric, boolean handicapped, boolean member, String arrived, String left, int tArrived, int tLeft, int location) {
		super(electric, handicapped, member, arrived, left, tArrived, tLeft, location);
		this.setNumOfSeats(seatNum);
	}
	
	
	
	public int getNumOfSeats() {
		return numOfSeats;
	}

	public void setNumOfSeats(int numOfSeats) {
		this.numOfSeats = numOfSeats;
	}

	public String toString() {
		return "I'm a Truckkkk";
	}
	

}
