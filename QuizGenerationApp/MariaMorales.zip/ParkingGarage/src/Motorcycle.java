
public class Motorcycle extends Vehicle{
	private int passangerNum;
	
	public Motorcycle() {
		
	}
	
	public Motorcycle(int pNum, boolean electric, boolean handicapped, boolean member, String arrived, String left, int tArrived, int tLeft, int location) {
		super(electric, handicapped, member, arrived, left, tArrived, tLeft, location);
		this.passangerNum = pNum;
	}

	public int getPassangerNum() {
		return passangerNum;
	}

	public void setPassangerNum(int passangerNum) {
		this.passangerNum = passangerNum;
	}
	
	public String toString() {
		return "I'm a Motorcycleeee";
	}
	

}
