
public class TicketMachine {
	private double parkingCost;
	private boolean gate;
	private boolean carExist;
	private String[] ticket;
	private String parkingSpace;
	private Vehicle memberID;
	
	public TicketMachine() {
		
	}//commit
	
	public TicketMachine(double pcost, boolean gate, boolean cExist, Vehicle v ) {
		
	}

	public double getParkingCost() {
		return parkingCost;
	}

	public void setParkingCost(double parkingCost) {
		this.parkingCost = parkingCost;
	}

	public boolean getGate() {
		return gate;
	}

	public void setGate(boolean gate) {
		this.gate = gate;
	}

	public boolean getCarExist() {
		return carExist;
	}

	public void setCarExist(boolean carExist) {
		this.carExist = carExist;
	}

	public String[] getTicket() {
		return ticket;
	}

	public void setTicket(String[] ticket) {
		this.ticket = ticket;
	}

	public String getParkingSpace() {
		return parkingSpace;
	}

	public void setParkingSpace(String parkingSpace) {
		this.parkingSpace = parkingSpace;
	}

	public Vehicle getMemberID() {
		return memberID;
	}

	public void setMemberID(Vehicle memberID) {
		this.memberID = memberID;
	}
	
	public Ticket printTicket() {
		Ticket newTicket = new Ticket();
		return newTicket;
	}
	
	public void feedTicket(Ticket ticket) {
		
	}
	
	public String speakLines() {
		String lines = "TBD";
		return lines;
	}
	
	public String speakLines(String l, int k) {
		// What are l and k?
		String lines = "TBD";
		return lines;
	}
	
	public double calculateTotal(Ticket ticket) {
		//Determine if you're a member or not, which vehicle you drive
		// return total based on that
		return 0.0;
	}
	
	
}
