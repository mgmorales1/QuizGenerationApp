
public class Bus extends Vehicle{
	
	private double length;
	
	public Bus() {
		
	}
	
	public Bus(int length, boolean electric, boolean handicapped, boolean member, String arrived, String left, int tArrived, int tLeft, int location) {
		super(electric, handicapped, member, arrived, left, tArrived, tLeft, location);
		this.length = length;
	}
	
	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}
	
	public String toString() {
		return "I'm a Bus hahaa";
	}


}
