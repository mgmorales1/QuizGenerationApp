

public class Car extends Vehicle{
	
	
	public Car() {
		
	}
	
	public Car(boolean electric, boolean handicapped, boolean member, String arrived, String left, int tArrived, int tLeft, int location ) {
		super(electric, handicapped, member, arrived, left, tArrived, tLeft, location);

	}
	
	public String toString() {
		return "I'm a Carr";
	}

	

}
