import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class ParkingGarage {
	
	public static void splitS(String s, String c) {
		String[] subS = s.split(c);
		System.out.print("DateString");
		
		for(int i = 0; i< subS.length; i++) {
			System.out.print(subS[i] + "" );
		}
	}

	public static ArrayList<Vehicle> makeVehicleList() {
		/* Stores the Vehicles created from input file */
		ArrayList<Vehicle> array = new ArrayList<Vehicle>();
		Scanner scan = null;
		try
	    {
			/* Sets scanner to read from file */
			scan = new Scanner(new File ("SampleInput.txt"));        
			/* Reads each line of the text file and  
		     * creates the appropriate type of Vehicle */
	        while( scan.hasNext()){
	        	String vType = scan.next();
	    
	        	if (vType.equals("Car")) {
	        		/* Car is created and added to the ArrayList */
				    Car newCar = new Car(scan.nextBoolean(), scan.nextBoolean(), scan.nextBoolean(), scan.next(), scan.next(), scan.nextInt(), scan.nextInt(), scan.nextInt() );
				    array.add(newCar);
				} else if (vType.equals("Motorcycle")) {
					/* Motorcycle is created and added to the ArrayList */
					Motorcycle newMotorcycle = new Motorcycle(scan.nextInt(), scan.nextBoolean(), scan.nextBoolean(), scan.nextBoolean(), scan.next(), scan.next(), scan.nextInt(), scan.nextInt(), scan.nextInt());
					array.add(newMotorcycle);
				} else if (vType.equals("Truck")){
					/* Truck is created and added to the ArrayList */
					Truck newTruck = new Truck(scan.nextInt(), scan.nextBoolean(), scan.nextBoolean(), scan.nextBoolean(), scan.next(), scan.next(), scan.nextInt(), scan.nextInt(), scan.nextInt());
					array.add(newTruck);
				} else if (vType.equals("Bus")){
					/* Bus is created and added to the ArrayList */
					Bus newBus = new Bus(scan.nextInt(), scan.nextBoolean(), scan.nextBoolean(), scan.nextBoolean(), scan.next(), scan.next(), scan.nextInt(), scan.nextInt(), scan.nextInt());
					array.add(newBus);
				}
						
	        	
	        }
	        scan.close();
	    }
	    catch( FileNotFoundException e )
	    {
	    	System.out.println("A FileNotFoundException was caught");
	        e.printStackTrace();
	    }
		
		return array;
	}

	public static void main(String[] args) {
		
		
//		ArrayList<Vehicle> bank = makeVehicleList();
//		
//		for (int i = 0; i < bank.size(); i++) {
//			System.out.println(bank.get(i).toString());
//		}
//		
//		//bank.get(i)args.getDateEnteredFormatted();
//		
		//Vehicle griffin = new Vehicle();
//				griffin.getDateEnteredFormatted();
		System.out.println("Lah");
		String s = "10/12/19";
		String[] subs = s.split("/");
		System.out.println("I am hereee");
		

	}

}
