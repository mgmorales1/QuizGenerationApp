
public class ParkingSpot {
// coming soon 
	//could be in the ticket and just go to the spot 
	// name of parking space is the key, hash table looks up if the space is avaiable of not
	// gives you locations in a 2d array 
	// 5 hash tables one for each floorrrr
	
	public ParkingSpot() {
		
	}
	
}
