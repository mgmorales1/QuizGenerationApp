import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Vehicle {
	private boolean isElectric;
	private boolean isMember;
	private boolean handicapped;
	private int parkingLocation;
	private int timeEntered;
	private int timeLeft;
	private String dateEntered; 
	private String dateLeft;
	
	public Vehicle() {
		dateEntered = "04.29.98";
	}
	
	public Vehicle(boolean electric, boolean member) {
		this.isElectric = electric;
		this.isMember = member;
	}
	public Vehicle (boolean electric, boolean handicapped, boolean member, String arrived, String left, int tArrived, int tLeft, int location) {
		this.isElectric = electric;
		this.handicapped = handicapped;
		this.isMember = member;
		this.dateEntered = arrived;
		this.dateLeft = left;
		this.timeEntered = tArrived;
		this.timeLeft = tLeft;
		this.parkingLocation = location; 
	}


	public boolean getIsElectric() {
		return isElectric;
	}

	public void setElectric(boolean isElectric) {
		this.isElectric = isElectric;
	}

	public boolean getIsMember() {
		return isMember;
	}

	public void setMember(boolean member) {
		this.isMember = member;
	}

//	public String getDecal() {
//		return decal;
//	}
//
//	public void setDecal(String decal) {
//		this.decal = decal;
//	}
	
	//public void goToSpace(Ticket ticket) {
		 
	//}
	
	public double calculateTotal(Ticket ticket) {
		return 0.0;
	}

	public boolean getHandicapped() {
		return handicapped;
	}

	public void setHandicapped(boolean handicapped) {
		this.handicapped = handicapped;
	}

	public int getParkingLocation() {
		return parkingLocation;
	}

	public void setParkingLocation(int parkingLocation) {
		this.parkingLocation = parkingLocation;
	}

	public int getTimeEntered() {
		return timeEntered;
	}

	public void setTimeEntered(int timeEntered) {
		this.timeEntered = timeEntered;
	}

	public int getTimeLeft() {
		return timeLeft;
	}

	public void setTimeLeft(int timeLeft) {
		this.timeLeft = timeLeft;
	}

	public String getDateEntered() {
		return dateEntered;
	}
	
	public static String determineMonth(String mNum) {
		String month = "";
		if (mNum.equals("01")) {
			month = "Jan";
		} else if (mNum.equals("02")) {
			month = "Feb";
		} else if (mNum.equals("03")) {
			month = "Mar";
		} else if (mNum.equals("04")) {
			month = "Apr";
		} else if (mNum.equals("05")) {
			month = "May";
		} else if (mNum.equals("06")) {
			month = "Jun";
		} else if (mNum.equals("07")) {
			month = "Jul";
		} else if (mNum.equals("08")) {
			month = "Aug";
		} else if (mNum.equals("09")) {
			month = "Sep";
		} else if (mNum.equals("10")) {
			month = "Oct";
		} else if (mNum.equals("11")) {
			month = "Nov";
		} else {
			month = mNum;
		}
		return month;
	}
	
	public void getDateEnteredFormatted() {
		String date = this.getDateEntered();
		//System.out.println(date);
		String[] array = new String[3];
		int i = 0;
		while(i < 3)
		{
			for(int j = 0; j < date.length(); j++)
			{	
				if(date.charAt(j) == '.')
				{
					i++;
					j++;
				}
				else
				{
					array[i] += date.charAt(j);
				}
			}
		}
		
		
		//String month = determineMonth(array[0]);
		
		//return array.toString(); 
	}

	public void splitS(String s, String c) {
		String[] subS = s.split(c);
		System.out.print("DateString");
		
		for(int i = 0; i< subS.length; i++) {
			System.out.print(subS[i] + "" );
		}
	}
	
	public void setDateEntered(String dateEntered) {
		this.dateEntered = dateEntered;
	}

	public String getDateLeft() {
		return dateLeft;
	}

	public void setDateLeft(String dateLeft) {
		this.dateLeft = dateLeft;
	}
	
	public String toString() {
		return "I'm a Vehicleeee";
	}
	
	
}
